import React from 'react';
import { mount } from 'enzyme';
import { sleep } from '../../../tests/utils';
import { Popup} from '..';

import mountTest from '../../../tests/shared/mountTest';


let wrapper;

mountTest(Popup);

describe("Popup", ()=> {
  it('should lazy render content by default', async () => {
    wrapper = mount(<Popup>
      <div className="foo" />
    </Popup>);
    expect(wrapper.find('.foo').exists()).toBeFalsy();
    await wrapper.setProps({ visible: true });
    expect(wrapper.find('.foo').exists()).toBeTruthy();
  });
  it('should change z-index when using z-index prop', async () => {
    wrapper = mount(
    // <Popup visible zIndex={10} />);
    <Popup visible style={{zIndex:10}} />);
    await sleep(0);
    expect(wrapper.find('.rc-popup').getDOMNode().style.zIndex).toEqual("10");
    expect(wrapper.find('.rc-overlay').getDOMNode().style.zIndex).toEqual("10");
  });

it('should lock scroll when visibled', async () => {
  wrapper = mount(<Popup visible />);
  expect(document.body.classList.contains('rc-overflow-hidden')).toBeTruthy();
  await wrapper.setProps({ visible: false });
  expect(document.body.classList.contains('rc-overflow-hidden')).toBeFalsy();
});


it('should allow to using teleport prop', async () => {
  const div = document.createElement('div');
  mount(
    <Popup visible teleport={div} />
  );

  expect(div.querySelector('.rc-popup')).toBeTruthy();
});

it('should render overlay by default', () => {
  wrapper = mount(
    <Popup visible />
  );
  expect(wrapper.find('.rc-overlay').exists()).toBeTruthy();
});

it('should not render overlay when overlay prop is false', () => {
  wrapper = mount(
    <Popup visible  overlay={false} />
  );
  expect(wrapper.hasClass('rc-overlay'));
});
it('should emit click-overlay event when overlay is clicked', async () => {
  const onClickOverlay = jest.fn();
  wrapper = mount(
    <Popup visible onClickOverlay={onClickOverlay} />
  );
  const overlay = wrapper.find('.rc-overlay');
  overlay.simulate('click');
  expect(onClickOverlay).toHaveBeenCalled();
});

it('should emit open event when visible prop is set to true', async () => {
  const onOpen = jest.fn();
  wrapper = mount(
    <Popup visible={false} onOpen={onOpen} />
  );
  await wrapper.setProps({ visible: true });
  expect(onOpen).toHaveBeenCalledTimes(1);
});

it('should emit close event when visible prop is set to false', async () => {
  const onClickOverlay = jest.fn();
  const onClose = jest.fn();
  wrapper = mount(
    <Popup visible onClickOverlay={onClickOverlay} onClose={onClose} />
  );
  const overlay = wrapper.find(".rc-overlay");
  await overlay.simulate("click");
  wrapper.setProps({ visible: false });
  expect(onClose).toHaveBeenCalled();
});

it('should change duration when using duration prop', () => {

  wrapper = mount(
    <Popup visible duration={500} />
  );

  const popup = wrapper.find('.rc-popup');
  const overlay = wrapper.find('.rc-overlay');
  expect(popup.getDOMNode().style.animationDuration).toEqual('500ms');
  expect(overlay.getDOMNode().style.animationDuration).toEqual('500ms');
});
it('should have "rc-popup--round" class when setting the round prop', () => {

  wrapper = mount(
    <Popup visible round />
  );

  expect(wrapper.find('.rc-popup--round').exists()).toBeTruthy();
});

it('should render close icon when using closeable prop', () => {
  wrapper = mount(
    <Popup visible closeable />
  );
  expect(wrapper.find('.rc-popup__close-icon').exists()).toBeTruthy();
});


it('should emit click-close-icon event when close icon is clicked', async () => {
  const onClickCloseIcon = jest.fn();
  const www = mount(
    <Popup visible closeable closeIcon="success"  onClickCloseIcon={onClickCloseIcon} />
  );
  const icon = www.find('.rc-popup__close-icon');
  await icon.simulate('click');
  expect(onClickCloseIcon).toHaveBeenCalled(); 
});


it('should render correct close icon when using close-icon prop', () => {
  wrapper = mount(
    <Popup visible closeable closeIcon="success" />
  );
  expect(wrapper.find('.rc-popup__close-icon')).toMatchSnapshot();
});

it('should change icon class prefix when using icon-prefix prop', () => {
  wrapper = mount(
    <Popup visible closeable iconPrefix="my-icon" />
  );

  expect(wrapper.html()).toMatchSnapshot();
});

it('should render overlay-content slot correctly', () => {
  wrapper = mount(
    <Popup visible>Custom Overlay Content</Popup>
  );
  expect(wrapper).toMatchSnapshot();
});

it('should allow to prevent close with before-close prop', async () => {

  const onClickOverlay = jest.fn();
  const www = mount(
    <Popup visible beforeClose={ () => false} onClickOverlay={onClickOverlay} />
  );

  const overlay = www.find('.rc-overlay');
  overlay.simulate('click');
  expect(overlay).toBeTruthy();

  await www.setProps({ beforeClose: () => true });
  overlay.simulate('click');
  expect(overlay.exists());
});

it('should not call before-close when visible prop becomes false', async () => {
  const beforeClose = jest.fn();
  wrapper = mount(
    <Popup visible beforeClose={beforeClose} />
  );
  await wrapper.setProps({ visible: false });
  expect(beforeClose).toHaveBeenCalledTimes(0);
});

});
